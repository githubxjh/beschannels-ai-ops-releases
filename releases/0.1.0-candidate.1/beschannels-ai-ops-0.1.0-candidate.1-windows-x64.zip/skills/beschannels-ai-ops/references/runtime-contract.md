# 运行契约

## 命令

通过 `scripts/invoke-runtime.ps1` 调用：

```text
doctor --output json
capabilities --output json
plan --request REQUEST_JSON --output json
next --run-id RUN_ID --output json
record --run-id RUN_ID --result RESULT_JSON --output json
status --run-id RUN_ID --output json
verify --run-id RUN_ID --output json
cancel --run-id RUN_ID --output json
update --channel canary|pilot|stable --output json
rollback --output json
```

所有标准输出都是单个 JSON 对象。`ok=false` 时按 `error.code` 停止或恢复，不从错误文本猜测状态。

## 请求

请求使用 `schema_version=1`，包含 `request_id`、`capability_id`、`business_goal`、`target_system`、`target_object`、`inputs`、`options` 和 `output_dir`。每个输入包含稳定 `input_id`、本地 `path` 和 64 位 SHA256。

请求文件可留在当前任务目录；CLI 持久状态只保存代号、大小、哈希和绑定，不保存客户值。

## 动作与结果

- `ask_user`：回写 `confirmed_decisions`。
- `confirm_write`：回写 `confirmed=true`、实时 `environment` 和 CLI 原样给出的 `confirmation_binding`，状态为 `confirmed`。
- `browser_action`：由 Codex 浏览器适配器执行，回写脱敏观察和相对证据引用。
- `local_action`：用确定性工具或任务专用脚本执行，记录输入输出哈希与验证结论。
- `blocked`：记录阻塞原因后停止。
- `complete`：调用 `verify` 结束。

result 必含 `schema_version`、`run_id`、`step_id`、`plan_sha256`、`status`、`observations`、`evidence_refs`。同一步重复提交相同结果是幂等；不同结果会返回冲突。

## 环境观察

系统动作前的环境对象固定包含 `host`、`account`、`tenant`、`browser_surface`、`connection_id`。不要把登录凭证、Cookie、验证码或完整页面内容写入结果。
