# 运行契约

## 命令

通过 `scripts/invoke-runtime.ps1` 调用：

```text
doctor --output json
capabilities --output json
preflight --capability lead-download|historical-field-create|legacy-data-clean --output json
field-types --output json
knowledge status --output json
knowledge search --query QUERY --output json
check-update --channel canary|pilot|stable --output json
plan --request REQUEST_JSON --output json
next --run-id RUN_ID --output json
record --run-id RUN_ID --result RESULT_JSON --output json
status --run-id RUN_ID --output json
verify --run-id RUN_ID --output json
cancel --run-id RUN_ID --output json
feedback prompt --run-id RUN_ID --output json
feedback submit --run-id RUN_ID --request FEEDBACK_REQUEST_JSON --output json
update --channel canary|pilot|stable --output json
rollback --output json
```

所有标准输出都是单个 JSON 对象。`ok=false` 时按 `error.code` 停止或恢复，不从错误文本猜测状态。

`doctor` 返回本次安装实际加载的 Skill、引用目录、知识索引状态和版本匹配状态。
`preflight` 只读检查运行时、Skill 和能力相关外部适配器需求，并返回 `ready`、`install_required`、`manual_action_required` 或 `degraded` 路径。它不安装软件、不修改配置，也不写入业务系统。
`check-update` 只读取并验签当前通道清单，不下载、不安装、不切换版本；返回
`up_to_date`、`update_available`、`channel_stale` 或 `check_unavailable`。
只有随后调用 `update` 并再次通过 `doctor`，才可向用户报告“已更新”。
更新不再被其他旧运行全局阻塞；旧运行继续前会检查其锁定版本。版本发生漂移时返回
`run_version_drift`，应先重新确认，不直接继续业务写入。

`field-types` 返回共享字段类型目录。`verified_creatable` 表示当前产品写入已验证；
`observed_probe_required` 表示只观察到产品界面，必须先做 schema probe；
`observed_system_managed` 表示由产品系统维护，不能由历史字段追加能力创建。

`knowledge status` 只读取安装包内的审核索引，并区分已接入能力、手册模块和 CLI 候选数量；`knowledge search` 返回主题、状态、摘要和飞书产品手册链接。
CLI 不在每次任务中抓取或改写飞书内容，完整细节由浏览器打开 `source_url` 查看。
`verified_cli` 才表示当前版本可执行；`knowledge_only` 仅表示手册入口；`candidate_cli` 是待评审的只读优先候选，不得自动路由为可执行能力。

`feedback prompt` 在任务完成、阻塞或失败后只生成一次可选提示；`feedback submit` 要求反馈请求显式包含 `consent=true`，只把脱敏事件写入本地 `feedback/outbox/`，不访问飞书或 GitHub。

## 请求

请求使用 `schema_version=1`，包含 `request_id`、`capability_id`、`business_goal`、`target_system`、`target_object`、`inputs`、`options` 和 `output_dir`。每个输入包含稳定 `input_id`、本地 `path` 和 64 位 SHA256。

请求文件可留在当前任务目录；CLI 持久状态只保存代号、大小、哈希和绑定，不保存客户值。

## 动作与结果

- `ask_user`：回写 `confirmed_decisions`。
- `confirm_write`：回写 `confirmed=true`、实时 `environment` 和 CLI 原样给出的 `confirmation_binding`，状态为 `confirmed`。
- `browser_action`：由 Codex 浏览器适配器执行，回写脱敏观察和相对证据引用。
- `local_action`：用确定性工具或任务专用脚本执行，记录输入输出哈希与验证结论。
- `blocked`：记录阻塞原因后停止。
- `complete`：调用 `verify` 结束。

result 必含 `schema_version`、`run_id`、`step_id`、`plan_sha256`、`status`、`observations`、`evidence_refs`。同一步重复提交相同结果是幂等；不同结果会返回冲突。

## 环境观察

系统动作前的环境对象固定包含 `host`、`account`、`tenant`、`browser_surface`、`connection_id`。不要把登录凭证、Cookie、验证码或完整页面内容写入结果。

## 浏览器导航

- 浏览器适配层默认使用稳定的 `host + path` 直达；只有记录在 `navigation-routes.json` 的租户兼容路径优先点击左侧菜单。
- 直达失败时可以回退到菜单点击，但必须回读最终 path、host 和页面标题/稳定正文；`direct_verified` 与 `click_verified` 分开记录。
- 登录页、错误页、租户不匹配、账号路由重定向和控制通道超时分别记录，不把控制通道超时写成网页失败。
- 长期保存的链接必须去除 query、fragment 和动态认证参数；跨租户或跨域链接不进入稳定路径库。
