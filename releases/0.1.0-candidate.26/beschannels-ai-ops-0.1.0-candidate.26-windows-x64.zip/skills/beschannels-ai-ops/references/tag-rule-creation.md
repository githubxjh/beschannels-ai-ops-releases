# 单条标签规则候选路径

请求创建标签规则时使用 `tag-rule-create` 通用探索路径，不能误用只创建标签的 `tag-operations`。当前只支持核验并尝试创建一条非活动类型规则；不同模板和定时更新时间语义仍需现场验证，不宣称批量能力。

## 输入与只读预检

先取得规则名称、业务目的、目标对象、条件语义和值、数据到达节奏，以及目标标签的名称、ID、分组和完整路径。输入不全时先补齐，不从历史案例推断字段键或 OPCO 映射。

在当前页面核对登录账号、租户、对象、实际字段和关系选项。按精确规则名查重：零条才能创建，一条保留已有项，多条停止。目标标签完整路径必须唯一一致；现场限额必须未满，实时人数估算必须大于零。历史人数不能替代实时估算。

一次性数据使用手动更新。持续到达的数据才讨论定时更新；时间语义未确认时不保存。活动类型规则保持暂停。

## 确认、保存与回读

将 `options.operation=create`、`options.requires_confirmation=true` 写入请求。只读预检完成后再展示一次确认卡，包含完整规则语义、目标标签、更新方式和单条范围，并复用 CLI 当前确认绑定。不得设置低风险来跳过确认。

确认后仅保存一次。独立按精确名称回读规则数量、对象、更新模式、策略、条件、目标标签和覆盖人数。发现超时、错误、字段错配或数量不明时先只读回查，记录不确定状态并停止，不重放保存。低风险读取最多重试两次，每次不超过三十秒。

不批量创建、不编辑、不删除、不复制、不重算已有规则。新会话只能从同一运行的已回读状态继续；保存结果不确定不能新建运行再次保存。页面证据不足时使用 `blocked`，不能仅凭成功提示把结果记成成功。

## CLI 回执

专用步骤依次为 `observe_environment → inspect_guarded_creation → confirm_plan → save_guarded_item_once → verify_guarded_item`。所有成功回执包含当前 `observations.environment`。

预检 `observations.preflight` 必须记录真实的 `exact_matches=0`、`quota_available=true`、`target_type=non_activity`、`tag_path_unique=true`、大于零的整数 `live_estimate`、`data_cadence=one_off/continuous`、`update_mode=manual/scheduled`；定时模式还需 `schedule_semantics_confirmed=true`，且仅适用于持续数据。预检整体绑定本次确认摘要。

保存回执记录 `submitted_once=true`。独立回读 `observations.readback` 必须包含 `exact_matches=1`、`independent=true`、`object_matches/update_mode_matches/conditions_matches/tag_path_matches=true`。这些字段只能从实际页面观察获得，附当前 `evidence_refs`；CLI 检查缺项和错配，不能证明 AI 填写的观察真实。已有一条则保留对象并说明，终止创建运行，不填写虚假的零条预检。失败或不确定不支持保存重试入口。
