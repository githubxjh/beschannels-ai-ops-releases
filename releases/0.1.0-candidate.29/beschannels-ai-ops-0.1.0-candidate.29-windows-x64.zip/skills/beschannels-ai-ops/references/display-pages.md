# 微页面搭建与独立验收

当用户需要活动集合页、微页面或展示型落地页时按需读取本页。使用 `landing-page-display` 和 `options.display_spec` 启用专用步骤。此版本覆盖新建展示页的 PC 搭建与 PC 独立展示验收；需要表单、外部跳转或修改已有业务页时重新明确范围，不能套用这里的无提交验收。

遇到 iframe 读取、上传或拖放问题时按需读取 [browser-frames.md](browser-frames.md)，使用现有工具或随包薄适配，不依赖作者本机代理端口和临时脚本。

## 输出、输入与确认

输出是当前租户中新建的原生微页面、同一对象的可恢复运行、独立展示证据及验收结论。预览视口不等于微信真机。源展示页只能作只读参考，跨租户不使用后台复制；可用素材重新导入当前测试页，不沿用源页表单和业务入口。

**搭建只在 PC 编辑模式进行。按模块先放对齐容器，再把该模块的内容组件放进去。例如一个图片模块应为“对齐容器 → 图片组件”，而不是直接在页面根部放图片组件。各模块分别使用自己的对齐容器。** 新任务只搭建和验收 PC；平板、手机不作为任务步骤或通过条件，也不宣称容器保证跨设备内容继承。“整页只套一个容器就足够”未经验证，不作为执行规则。旧请求显式声明的三设备契约继续兼容，不自动修改已有运行的请求和证据。

用户材料必须说明模块顺序、文案、素材对应和导航目标。文件作为请求 `inputs` 锁定。`display_spec` 只保存如下结构和哈希，文案正文留在任务材料里：

```json
{"operation":"create","display_spec":{"layout_strategy":"pc_module_containers","devices":["pc"],"modules":[
  {"key":"hero","kind":"carousel","asset_input_ids":["hero_a","hero_b"],"text_sha256":[]},
  {"key":"activity_a","kind":"activity","asset_input_ids":["activity_a"],"text_sha256":["文案摘要占位，实际填写64位大写SHA256"]},
  {"key":"zones","kind":"tabs","asset_input_ids":["zone_a","zone_b"],"text_sha256":["两个标签按顺序各一个文案摘要"]},
  {"key":"nav","kind":"anchor","asset_input_ids":[],"text_sha256":["按钮文案摘要"],"anchor_target":"zones"}
]}}
```

示例中的摘要占位必须用实际值替换。文案摘要算法：去掉首尾空白、连续空白折叠为一个空格，再对 UTF-8 字节计算大写 SHA256。活动标题与说明按显示顺序各一个摘要；标签按显示顺序各一个摘要。`heading` 用于独立标题。逻辑模块键稳定，但编辑器控件 ID 每次实时发现，不能写进 Skill。

仍走 `plan → next → 动作 → record → verify`。在检查步骤完成当前账号租户、同名排查、创建权限和保存是否立即影响展示链接后，沿用当前计划唯一确认。测试环境已有明确范围授权可记录该授权，不能伪造新回复；正式协作展示一次范围确认。

## 当前步骤内的浏览器操作

1. 从当前登录后台进入原生落地页列表，选空白模板创建独立对象。成功后立即记录真实对象标识和列表回读；若创建结果不确定，先按本次精确名称查找，禁止直接再次创建。
2. 每个 `configure_display_module` 只处理 `display_context.module_key` 指定模块。先检查并建立该模块的对齐容器，再在其中配置内容；续接复用该模块已有的容器，不把其他模块的容器作为全页公共容器。始终在 PC 模式编辑、保存，再只读回查 PC 展示。每次续接先 `status`、`next`，使用 CLI 返回的 `target_ref`。有已完成模块或容器时先查结构，不能重新拖入一套。
3. 从当前组件面板定位轮播、横向容器、图片、文字、标签和跳转按钮。拖拽先 `dragstart/dragenter/dragover`，待占位更新再 `drop/dragend`，随后读 DOM 确认增加的控件和父级。当前编辑器的落点处理有约 100 毫秒延迟；快速浏览器调用须等待落点更新，不能紧接着发送 drop。内容组件必须属于当前模块的对齐容器，活动图片或标签图片还要核对具体所属面板；只看到控件新增不算成功。一次失败先查已有控件并移动回正确父级，避免重复添加。
4. 轮播的编辑入口可能在组件的外层操作栏。只修改当前模块的轮播弹窗，删掉多余默认项，按顺序上传对应素材，清空默认标题、描述和业务链接。文件输入后完成裁剪弹窗，核对实际上传预览再保存弹窗和页面。
5. **轮播只在 PC 模式配置和验收**，并放在轮播模块自己的对齐容器内。平板和手机不属于本能力的验收范围，不要求配置或同步其他设备内容。历史页面已有分端覆盖时也不能当作干净样本。
6. 图文活动用原生容器、图片和富文本；新增或移动子项可能重新平均分配宽度，应在 PC 模式完成布局后检查 PC 视口的比例与溢出。富文本等公开编辑器实例初始化后再写入，触发正常失焦保存；不要修改框架内部状态或调用未授权业务接口。
7. 标签组件默认数量可能超过需求。先选择多余标签再用减号删除，逐个检查标签文案与对应面板图片。页内导航使用原生跳转按钮的“页面位置”选项，绑定当前页真实目标模块；富文本手写锚点可能被改为 `#blocked`，不能用它替代原生导航。
8. 保存后关闭或刷新编辑器重新进入同一对象；独立浏览器从展示链接加载，不从编辑器画布推断持久化。PC 独立展示失败要在当前步骤修正或记录失败，不能先记录成功再补证据。

浏览器连接、上传和输入由当前平台适配工具完成；端口、绝对路径、会话 ID 留在本地适配配置。核心不依赖 Codex 专用浏览器。只有实际跑过的平台才声明真实后台验证。

## 回执与证据契约

除环境观察与确认外，每步成功回执的 `observations` 包含实时 `environment`、相对输出目录的 `evidence_ref`、证据文件大写 `evidence_sha256`；创建后还包含 `target_ref`。同一引用必须列入 `evidence_refs`。证据 JSON 必须绑定本次 `run_id/step_id/plan_sha256`，禁止使用旧页截图倒填新步骤。

| 步骤 | 证据要求 |
|---|---|
| `inspect_display_target` | `duplicate_checked/create_new_allowed/save_affects_public_acknowledged` 均为实际观察或已授权的 true |
| `create_display_page` | `target_ref`、`created_once/object_readback=true`，保留精确名称查找结果 |
| `configure_display_module` | `surface=editor`、`saved=true`、`target_ref`、`devices` 对象包含 PC 模块指纹 |
| `reopen_display_editor` | `surface=editor`、`reopened=true`、同一 `target_ref` |
| `verify_display_device` | `surface=public`、当前 `device`、同一 `target_ref`、按请求顺序排列的 `modules` 指纹、下列全部检查 |

模块指纹结构为 `{"key":"hero","asset_sha256":["实际素材摘要"],"text_sha256":["实际文案摘要"]}`。从当前画面和独立展示的真实 DOM 采集：按模块与交互顺序取图片地址，取可见标题/描述/标签文案。实际展示资源下载后字节摘要应与输入匹配。平台已观测的纯格式转换 `?imageMogr2/format/webp` 可另外下载去掉该查询串的同地址原图，在素材项增加 `original={"url":"同地址原图URL","file":{"ref":"实际下载的原图","sha256":"原图摘要"}}`；原图必须匹配输入摘要，转换图与原图均留存并视觉核对。裁剪、缩放或其他处理参数保持未验证。不能复制输入文件冒充展示下载资源。

PC 独立展示检查 `images_loaded/no_overflow/no_stretch/no_forms/no_external_navigation/interactive_states/anchor/editor_reopened` 必须全部满足。保留当前展示采集数据、截图和交互前后结果作为证据附加字段：每张图加载成功；比例正确；无横向溢出；无表单；轮播与标签逐项切换后素材正确；导航滚动到目标；没有业务跳转或提交；重开后的内容一致。截图空白、默认文案残留、点击没有生效均为失败。

展示验收还要保存 DOM 层级，逐模块核对“对齐容器 → 内容组件”的归属，并检查活动图片、文案和标签图片的实际面板。新请求声明 `layout_strategy=pc_module_containers`，CLI 校验模块容器、PC 搭建标识及内容父级，并拒绝多个模块共用同一容器。旧请求保持原校验兼容。结构证据必须来自真实 DOM，不能用声明替代采集。PC 验收失败时检查对应模块的布局、素材和持久化结果。

证据文件校验能拒绝缺项、错图、错设备、错对象和文件漂移，但不能证明编造的观察是真实的。**验收数据必须由独立展示会话实际采集，不能由 AI 抄请求或只填写全部 true。** CLI 终检会重读证据；`verified=true` 的范围是本契约及其证据成立，不能升级为业务审核、真机验收或正式发布。

### 独立展示采集文件

展示证据还必须含 `capture={"ref":"当前设备采集.json","sha256":"文件摘要"}`。所有文件引用均相对请求的输出目录，不能指向目录外。采集 JSON 包含与本步一致的 `run_id/step_id/plan_sha256/target_ref/device`，以及以下字段；摘要占位必须替换为实际文件摘要。

```json
{
  "source":"browser_dom", "surface":"public", "url":"https://example.invalid/current-page",
  "viewport":{"width":1280,"height":800,"scroll_width":1280},
  "modules":[{
    "key":"hero", "texts":[],
    "assets":[{
      "file":{"ref":"downloaded-hero.png","sha256":"实际下载字节摘要"},
      "displayed_src":"https://example.invalid/hero.png",
      "downloaded_from":"https://example.invalid/hero.png",
      "natural_width":1200,"natural_height":600,
      "rendered_width":1000,"rendered_height":500
    }],
    "selected_indices":[0],
    "screenshots":[{"ref":"hero-state-0.png","sha256":"截图摘要"}]
  }]
}
```

设置 PC 视口后重新加载独立展示页或展示 iframe。确认加载完成、实际视口宽度正确后，再逐个滚动到模块、加载图片、切换轮播及标签并采集；`modules`、`texts` 和 `assets` 与需求的逻辑顺序一致。文字保存实际展示文本，CLI 自行折叠空白并计算摘要。素材从 `displayed_src` 实际下载到输出目录，`downloaded_from` 必须是同一地址；图片自然尺寸读 DOM，显示尺寸读当前元素矩形。页面宽、高和 `scroll_width` 分别取视口与文档滚动宽度。

每个模块至少一张实际 PNG 截图；轮播和标签按每个选中状态各保留一张截图，`selected_indices` 按零起始索引完整记录。导航模块另含 `anchor={"target_key":"目标模块键","target_top_after":0,"url_before":"展示页地址","url_after":"展示页地址"}`，点击后读取目标位置与地址。保留 DOM 原始坐标；目标顶部允许不足 1 CSS 像素的负值作为滚动舍入差，即 `-1 < target_top_after < viewport.height`，不得改写坐标来规避校验。CLI 检查内容摘要、加载尺寸、比例误差不超过 3%、无横向溢出、截图文件存在、状态覆盖和导航结果。图片视觉对应及截图内容仍需实际审阅；文件哈希不能证明截图没有造假，也不能证明微信真机通过。

## 中断与失败

每次模块保存回读成功马上 `record`，随后中断不会重建对象。若保存已发生但回执未落盘，续接仍在同一步：读取当前目标模块，确认已存在并采集当前证据再记录，不重复创建或追加。发生环境、输入、版本或对象漂移时沿用既有停止机制。以失败结束的运行保留证据，不手改状态绕过引擎。

模块配置已记录 `failed` 时，先排除上传或连接故障，再用 `next --run-id <RUN_ID> --retry-failed` 显式续接。CLI 先归档失败回执和原始证据，再返回原对象的同一模块；每步最多三次恢复。恢复后必须重新核对当前环境和已有组件，再操作、保存、独立回读。新证据使用新文件名，保留原证据。创建失败、`blocked`、`cancelled` 或任一漂移不支持这个入口，不能修改状态或重新建页绕过停止条件。

### 模块结构回读

新请求的模块保存证据增加 `structure`，例如 `{"authoring_device":"pc","container_id":"CONTAINER_A","content_ids":["IMAGE_A"],"nodes":[{"id":"CONTAINER_A","type":"flexBox","parent":null},{"id":"IMAGE_A","type":"image","parent":"CONTAINER_A"}]}`。节点 ID、类型和父级从当前编辑器 DOM 读取，包含每个内容组件到该模块容器的完整祖先链；不能仅填写示例值。不同模块必须用不同的容器 ID。独立展示仍需验收真实尺寸和图片，结构检查不能证明适配效果。
