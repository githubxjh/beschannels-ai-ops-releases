# 旧版资料分类受控路径

按已确认模板补建旧版“资料下载 → 资料分类”时，使用 `legacy-material-category-create` 通用探索路径。本参考用于单项受控尝试；完整批次恢复和跨平台后台操作尚未验证。

## 输入与路径

先解析模板 OPCO、用户确认的页面 OPCO 映射、父级完整路径、去掉 OPCO 前缀后的页面名称、层级和来源位置。不能推断服务号映射。活动管理模板只是输入来源，实际写入位置是旧版资料分类，不能误写到活动分类或新版资料。

先核对当前账号、租户、主机、旧版页面和 OPCO 选择器，再展开父级。精确查重键为 `页面 OPCO + 父级路径 + 去前缀名称 + 层级`：已有唯一节点则保留，缺失且配额允许才进入创建，多重匹配或层级不明时停止。一级配额满时不能换到未确认的服务号继续。

## 单项确认与回读

使用 `options.operation=create` 和 `options.requires_confirmation=true`。在当前 CLI 的只读步骤完成预检后，展示包含 OPCO、父级、页面名称、层级、输入摘要和回读方法的一次确认卡。确认绑定不变才执行当前步骤；不设置低风险来绕过确认。

默认通过可见页面操作，单次保存后独立回读树节点，确认名称、OPCO、父级和层级全部一致。接口结构变化时回到页面；本包不提供裸 API 执行器。后端创建非幂等，因此保存超时、不明确或回读失败时只能只读回查并停止，禁止重放。

已验证的一种旧版页面通过“添加 → 输入名称 → 输入框失焦”立即创建二级节点；页面底部“保存”用于排序，不能作为新增分类提交入口。先核对当前页面真实控件及提示，填写名称后仅触发一次已确认的提交事件，等列表回读到真实节点 ID，再刷新独立回读。后台未聚焦时原生失焦可能没有触发提交；只读确认没有发出创建请求后，才可使用已有浏览器工具触发一次同名 DOM 失焦事件。请求是否发出不明时保持停止，不补点。新节点显示状态以保存后的页面为准，不能把输入中临时显示的“隐藏”当作持久状态；本路径不调整显示状态或排序。

结果逐项区分已创建、已存在、阻塞和部分完成。当前不开放无保护批量、自动重试、自动回滚；禁止删除、移动、合并、重命名、显示、隐藏、排序或编辑已有分类。也不上传资料。完整清单任务应先只读盘点，不能把单项能力声称为完整批次恢复能力。

## CLI 回执

专用步骤依次为 `observe_environment → inspect_guarded_creation → confirm_plan → save_guarded_item_once → verify_guarded_item`。所有成功回执包含当前 `observations.environment`。

预检 `observations.preflight` 记录真实的 `exact_matches=0`、`quota_available=true`、`page_generation=legacy_download`、`opco_mapping_confirmed/parent_path_unique/prefix_removed=true`，以及整数 `level=1/2`。预检整体绑定本次确认摘要。已有唯一节点时保留并说明，终止创建运行，不谎报零条匹配。

保存后记录 `submitted_once=true`。独立回读 `observations.readback` 必须包含 `exact_matches=1`、`independent=true`、`opco_matches/parent_path_matches/name_matches/level_matches=true`，附真实树节点 `evidence_refs`。CLI 检查缺项和错配，不能证明回写观察的真实性。保存结果不明确时返回 `blocked/failed` 并保存证据，不通过重新计划或重试入口再次保存。
