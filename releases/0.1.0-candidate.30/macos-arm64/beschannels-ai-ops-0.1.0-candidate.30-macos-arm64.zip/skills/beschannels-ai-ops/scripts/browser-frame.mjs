// 可选 Chrome CDP 薄适配。连接由同事已有浏览器工具提供，不启动或切换浏览器。
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createInterface } from 'node:readline';

function redact(value) {
  if (Array.isArray(value)) return value.map(redact);
  if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([k, v]) => [k, redact(v)]));
  if (typeof value !== 'string') return value;
  try {
    const url = new URL(value);
    for (const key of [...url.searchParams.keys()]) if (/^(auth(?:entication)?|token|code|key|secret|password|cookie|email)$/i.test(key)) url.searchParams.set(key, '[REDACTED_QUERY]');
    value = url.href;
  } catch {}
  return value.replace(/\b[^\s@]+@[^\s@]+\.[^\s@]+\b/g, '[REDACTED_EMAIL]');
}

export async function execute(input) {
  const endpoint = new URL(input.endpoint);
  if (!['ws:', 'wss:'].includes(endpoint.protocol) ||
      !['127.0.0.1', 'localhost', '[::1]'].includes(endpoint.hostname) ||
      endpoint.username || endpoint.password || endpoint.search || endpoint.hash) {
    throw new Error('仅接受当前已授权浏览器的本机 CDP WebSocket 地址');
  }
  if (!input.target || !['session', 'frames', 'eval', 'click', 'upload', 'screenshot'].includes(input.operation)) {
    throw new Error('必须提供已核对的 target 与受支持操作');
  }
  const socket = new WebSocket(endpoint);
  const pending = new Map();
  const contexts = new Map();
  let counter = 0;
  const failPending = () => {
    for (const item of pending.values()) {
      clearTimeout(item.timer);
      item.reject(new Error('CDP 连接已关闭；当前动作结果不确定，先只读回查'));
    }
    pending.clear();
  };
  socket.addEventListener('close', failPending);
  socket.addEventListener('message', event => {
    const message = JSON.parse(event.data);
    if (message.id && pending.has(message.id)) {
      const item = pending.get(message.id);
      clearTimeout(item.timer);
      pending.delete(message.id);
      if (message.error) item.reject(new Error('CDP 操作失败：' + message.error.message));
      else item.resolve(message.result);
    }
    if (message.method === 'Runtime.executionContextCreated') {
      const context = message.params.context;
      if (context.auxData?.isDefault) contexts.set(context.auxData.frameId, context.id);
    }
    if (message.method === 'Runtime.executionContextsCleared') contexts.clear();
    if (message.method === 'Runtime.executionContextDestroyed') {
      for (const [frame, id] of contexts) if (id === message.params.executionContextId) contexts.delete(frame);
    }
  });
  function command(method, params = {}, sessionId) {
    return new Promise((resolve, reject) => {
      const id = ++counter;
      const timer = setTimeout(() => {
        pending.delete(id);
        reject(new Error('CDP 操作超时；不自动重试写入'));
      }, 15000);
      pending.set(id, {resolve, reject, timer});
      socket.send(JSON.stringify({id, method, params, ...(sessionId ? {sessionId} : {})}));
    });
  }
  try {
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('浏览器连接超时；请检查已有授权连接')), 15000);
      socket.addEventListener('open', () => { clearTimeout(timer); resolve(); }, {once: true});
      socket.addEventListener('error', () => { clearTimeout(timer); reject(new Error('浏览器连接失败')); }, {once: true});
    });
    const {sessionId} = await command('Target.attachToTarget', {targetId: input.target, flatten: true});
    await command('Page.enable', {}, sessionId);
    await command('Runtime.enable', {}, sessionId);
    async function perform(input) {
    if (!['frames', 'eval', 'click', 'upload', 'screenshot'].includes(input.operation)) throw new Error('未知操作');
    const {frameTree} = await command('Page.getFrameTree', {}, sessionId);
    const frames = [];
    const visit = node => {
      const url = new URL(node.frame.url || 'about:blank');
      frames.push({frame: node.frame.id, parent: node.frame.parentId || null,
                   origin: url.origin, path: url.pathname});
      for (const child of node.childFrames || []) visit(child);
    };
    visit(frameTree);
    if (input.operation === 'frames') return {frames};
    const frame = input.frame || frameTree.frame.id;
    if (!frames.some(item => item.frame === frame) || !contexts.has(frame)) {
      throw new Error('目标 iframe 上下文不可用；重新发现 frames，不回退到外层页面');
    }
    async function evaluate(expression, byValue = true) {
      const result = await command('Runtime.evaluate', {expression, contextId: contexts.get(frame),
        awaitPromise: true, returnByValue: byValue}, sessionId);
      if (result.exceptionDetails) throw new Error('页面脚本执行失败；不自动重试');
      return result.result;
    }
    if (input.operation === 'eval') {
      if (typeof input.expression !== 'string') throw new Error('缺少 expression');
      return {value: (await evaluate(input.expression)).value};
    }
    if (input.operation === 'click') {
      if (typeof input.selector !== 'string') throw new Error('缺少 selector');
      return {value: (await evaluate(`(()=>{const es=document.querySelectorAll(${JSON.stringify(input.selector)});if(es.length!==1)throw Error('需要唯一元素');es[0].click();return true})()`)).value};
    }
    if (input.operation === 'upload') {
      if (!Array.isArray(input.files) || !input.files.length || input.files.some(file =>
          typeof file !== 'string' || !path.isAbsolute(file) || !fs.statSync(file).isFile())) {
        throw new Error('上传文件必须是实际存在的绝对路径');
      }
      if (typeof input.selector !== 'string') throw new Error('缺少 selector');
      const element = await evaluate(`(()=>{const es=document.querySelectorAll(${JSON.stringify(input.selector)});if(es.length!==1||es[0].tagName!=='INPUT'||es[0].type!=='file')throw Error('需要唯一文件输入框');return es[0]})()`, false);
      if (!element.objectId) throw new Error('文件输入框不存在');
      await command('DOM.setFileInputFiles', {files: input.files, objectId: element.objectId}, sessionId);
      return {assigned: true, saved: false};
    }
    if (input.operation === 'screenshot') {
      if (typeof input.output !== 'string' || !path.isAbsolute(input.output)) throw new Error('截图输出必须是绝对路径');
      await command('Page.bringToFront', {}, sessionId);
      const image = await command('Page.captureScreenshot', {format: 'png'}, sessionId);
      fs.writeFileSync(input.output, Buffer.from(image.data, 'base64'), {flag: 'wx'});
      return {captured: true, surface: 'top_level_viewport'};
    }
    }
    if (input.operation === 'session') {
      console.log(JSON.stringify({ok: true, ready: true}));
      const lines = createInterface({input: process.stdin, crlfDelay: Infinity});
      for await (const line of lines) {
        try {
          const request = JSON.parse(line);
          if (request.endpoint || request.target) throw new Error('会话已绑定 target，不能在会话内漂移');
          console.log(JSON.stringify(redact({ok: true, ...(await perform(request))})));
        } catch (error) {
          console.log(JSON.stringify(redact({ok: false, error: error.message})));
        }
      }
      return {closed: true};
    }
    return await perform(input);
  } finally {
    failPending();
    socket.close();
  }
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    const input = JSON.parse(fs.readFileSync(process.argv[2], 'utf8').replace(/^\uFEFF/, ''));
    console.log(JSON.stringify(redact({ok: true, ...(await execute(input))})));
  } catch (error) {
    console.log(JSON.stringify(redact({ok: false, error: error.message})));
    process.exitCode = 1;
  }
}
