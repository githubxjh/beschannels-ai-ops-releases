# 行动确认卡

在任何真实创建/发布或有界编辑前，立即展示本确认卡。

```yaml
action: create_and_publish | bounded_edit
host: <精确主机>
visible_account: <脱敏后的可见账号标识>
system_identity_source: <组织 ID 已核对但不展示实际值，或明确客户/系统名称>
target_page: <新建会议页或既有活动 ID>
meeting_name: <精确名称>
input_sha256: <规范化输入哈希>
duplicate_check:
  query: <已核对系统中的名称 + 时间>
  exact_matches: <整数>
  checked_at: <时间戳>
fields:
  category: <精确 ID/路径/文字>
  start_at: <值>
  end_at: <值>
  meeting_mode: <值或 unverified>
  offline_address: <值或跳过原因>
  live_platform: <精确已观察选项或跳过原因>
  live_url: <脱敏摘要或跳过原因>
modules:
  promotion_settings: <已配置字段或 blocked>
  promotion_links: <已配置字段或跳过原因>
  official_account: <已配置字段或跳过原因>
  wecom_activity: <已配置字段或跳过原因>
  tags: <精确 ID/路径或跳过原因>
  offline_checkin: <已配置字段或跳过原因>
  data_statistics: <仅回读或已验证行为>
  rules: <精确规则或跳过原因>
write_effect: <直接发布，无草稿阶段>
automatic_delete_rollback: false
readback: <系统 ID + 核心字段 + 模块状态>
```

确认只对一次动作有效。计划、输入哈希、主机、账号、系统身份、查重结果或目标有任何变化，都必须重新确认。
