---
name: beschannels-ai-ops
description: 统一调用致趣 AI 工作台处理同事描述的 BesChannels 运营与实施任务。参考能力覆盖表单资料二维码、活动会议、历史数据、历史字段、标签、直播和 PC 微页面；目录之外的自然语言需求进入当前环境探索。高风险数据和权限动作按影响范围确认，同事不需要知道 Skill 名、CLI、路径或内部对象 ID。
metadata:
  version: "0.1.0-candidate.40"
  white_box_protocol: "v1"
---

# 致趣 AI 工作台

## 项目共同认知（必读）

先读取 [references/AI_ORIENTATION.md](references/AI_ORIENTATION.md)。本文件说明项目使命、训练单位、会议能力优先级和证据边界；它与训练项目的 `AI_ORIENTATION.md` 由同一版本和 SHA256 约束。启动时使用 `orientation status --output json` 检查已加载的共同认知，再开始能力路由。

把用户的业务描述路由为可验证运行。能力目录是参考路径，不是业务能力白名单；目录未覆盖的需求继续进入通用探索。对用户只显示中文产品名、业务范围、必要问题、风险确认和结果；CLI 名、内部路径、哈希与对象 ID 仅用于内部执行和诊断。

## 同事环境优先

同事是业务用户，不是开发者。案例文档中的账号、租户、表单、字段、活动、直播间和资料名称只用于说明格式，不能当作当前任务的目标值，也不能假定同事能看到。每次浏览器任务必须先读取当前登录账号、当前租户和当前页面入口；若无法确认当前环境，先用业务语言请同事登录自己的测试环境，再继续。

- 不向同事展示版本号、通道名、候选生命周期、哈希、CLI、路径、内部对象 ID 或诊断字段。内部检查结果只转换为“当前环境已准备好 / 需要登录或授权 / 当前环境没有这个对象 / 需要补充测试对象”四类业务提示。
- 不复用案例中的测试对象或直播间。只有当前账号和租户页面实际可见、且同事明确确认的对象才可继续；对象不存在时先停止并让同事选择“使用已有测试对象”或“在当前环境创建新的合成对象”。
- 字段、表单分类、活动模块和直播平台以当前环境实时枚举为准。案例中的示例字段或模块只作为输入示例，不作为默认配置。
- 后台页面不一定显示租户名称（本测试环境的组织信息页公司名称为空，租户切换页只有「我的租户」和空列表）。读不到租户名称时，以当前登录账号、当前公众号名称和访问域名作为环境依据，向同事说明并请同事确认一次，不要因此停下整个任务。确认卡和回复里写公众号名称和访问域名，不要写组织 ID、账号邮箱这类内部标识。
- 本地 CSV/PDF 清洗可以在没有业务系统登录态时先做；涉及浏览器写入、活动绑定或资料配置时，必须先完成当前环境核验，再单独确认业务写入。

## 客户记忆

同事提到具体客户并要你搭建、修改东西时，开始前先按 [customer-memory.md](references/customer-memory.md) 找该客户的「客户记忆」文件：有就读，并在确认卡里单列「按该客户习惯：…」；没有就照标准做法。同事这次说的话永远比记忆大；安全规矩（先查重、只确认一次、做完独立回读、不动别人建的对象、重名或缺表单要停下来问）任何记忆都不能覆盖；记忆里的要求页面做不到时，如实说「做不到，需要人工」，不要假装做了。做完且回读通过、同事说「以后都这样」时，问一句要不要记进客户记忆，同意才写。

## 路由

先读自动生成的 [adopted-contracts.json](references/adopted-contracts.json)，再读 [capability-routing.md](references/capability-routing.md)。前者是所有平台共同遵守的最低业务契约，不单独人工编辑；后者负责具体能力路由。优先选择一个参考能力；若没有精确匹配，使用通用探索路由：

浏览器入口由适配层按 [runtime-contract.md](references/runtime-contract.md) 处理：稳定路径优先直达，租户兼容路径回退左侧菜单；到达后必须校验最终页面。老页在 `app.` 子域，登录会比主域先过期：页面跳到登录页时应请同事重新登录，不要当成权限不足或页面不存在。表单、资料和二维码任务还必须读取 [form-taxonomy.md](references/form-taxonomy.md)，先在当前页面区分老/新表单和现代资料/旧版资料下载。导航策略不是新的业务能力，也不绕过账号、租户或写入确认门禁。

- `lead-download`：留资表单、下载资料、二维码及端到端验收。
- `activity-meeting-create`：活动/会议创建、配置、回读和按需统计。新会议搭建前读取[完整会议规则](references/activity-meeting/SKILL.md)，并按需加载其参考文件。
- `historical-data-clean`：检查、清洗、审计和验证历史 Excel/CSV。
- `historical-field-create`：创建、修改、删除历史字段并回读 schema 差异。
- `tag-operations`：标签创建、删除、覆盖、批量改名和断点恢复。
- `live-operations`：直播间创建、配置、回读和按需探索统计。

- `landing-page-display`：微页面、活动集合页和展示型落地页按需读取 [display-pages.md](references/display-pages.md)，以 `options.display_spec` 使用逐模块对齐容器、PC 保存与独立展示验收。新任务只声明 `devices=["pc"]`，不配置或验收平板、手机。其他探索任务继续沿用原契约。

- `marketing-automation`：营销自动化需求可行性判断、触发/人群/字段/节点设计和授权环境草稿搭建。按需读取 [营销自动化 Skill](../beschannels-marketing-automation/SKILL.md) 及其完整参考目录；保存后必须重新打开执行表单核对动态收件人、字段、连接和延迟。该能力当前仅为候选，不启用流程、不发送消息、不修改真实线索。

新建字段按需读取 [field-create.md](references/field-create.md)（命名规则、类型要点、选项值维护、读回和导出；字段名称与类型保存后不能改，所以保存前逐个核对）。企微群发按需读取 [wecom-mass-send.md](references/wecom-mass-send.md)（对外发送，默认只配到草稿，「发送」由同事本人点）。邮件模板与邮件群发按需读取 [email-template-and-mass.md](references/email-template-and-mass.md)（HTML 先给同事确认再导入；变量只对圈选对象收件人有效；对外发送，默认只配到草稿）。新表单（留资表单）搭建按需读取 [form-build.md](references/form-build.md)（字段属性、保存读回与偶发失败、字段多的表单怎么分批保存读回、保存后编辑器打不开就是存坏了、发布后弹窗的自动化选项一律不点）。新建会议按需读取 [activity-create.md](references/activity-create.md)（点「确定」就是创建并发布，只点一次；报名表单只列已发布的；先建一条、读回、同事确认后再批量；公众号、标签、企微活码、线下签到怎么配，以及同事本人扫码报名、签到的实测结果，也在里面）。迁移用的活动规格表和迁移对照表是固定模板，文件在本 Skill 的 `templates/` 目录（xlsx 和 csv 两种格式，复制一份来填，不要自己新建表格、不要改列），用法和填写规矩见 [migration-tables.md](references/migration-tables.md)。

创建标签规则按需读取 [tag-rule-creation.md](references/tag-rule-creation.md)，旧版资料分类按需读取 [legacy-material-categories.md](references/legacy-material-categories.md)，资料页（老页：资料下载 → 资料列表；新页：活动管理 → 活动列表 → 资料）按需读取 [material-page.md](references/material-page.md)。它们使用单项受控探索路径，先现场预检、一次确认、单次保存、独立回读；不能当作批量能力或跨平台实测完成。资料页的正文图片、封面裁剪和隐私条款三项必须按 material-page.md 的硬规则执行，并以保存后的页面回读为准。新页一次提多份时，按 material-page.md「一次要建多份」逐份做、任何一份停下整批停；这不等于开放无保护的批量能力。

目录未覆盖的会议、直播统计、报表、字段或标签近邻需求进入通用探索；只读和低风险动作直接执行，高风险动作按风险策略确认。

## 启动

1. Windows 使用 `scripts/invoke-runtime.ps1`，macOS/Linux 使用 `scripts/invoke-runtime.sh`，执行环境检查；检查细节只留在内部运行记录，不向同事展示工程状态。运行程序、说明书和模板都在本 Skill 目录里（`references/`、`templates/`、`scripts/`），不要为了找它们去全盘搜索；这里没有的东西就是这一版没有，不要凭想象补。
2. 每个新任务开始时，先执行 `check-update --channel <当前安装通道>`（只读，不改任何东西），按结果处理：
   - `update_available`：执行 `update --channel <当前安装通道>`（需要联网）。它激活签名版本，并把新版技能同步到本机所有 agent 的技能目录。更新完成后，重新读本文件和这次要用的 references、templates，再继续：这次对话里已经读过的文字可能是旧版。然后重新执行 `doctor`。
   - `up_to_date`：直接继续。`channel_stale`：忽略这次通道结果，继续用已装版本。
   - `check_unavailable`（没有网络）：继续使用已安装版本，并把版本状态标为“通道检查暂不可用”。

   已有旧运行不阻塞新任务更新。
3. 执行 `doctor`。`version_status` 为 `skill_root_stale`（`skill_roots_status` 为 `stale`；`preflight` 里同样会出现 `skill_roots` 一项，`next` 为 `sync_skills`）说明有的 agent 技能目录还是旧版。执行 `sync-skills`（离线、不联网、只改我们自己的两个技能目录），再执行一次 `doctor`，确认变回 `matched`。仍有目录没更新成功时，只对同事说是哪个助手（Codex、DeepSeek Harness、Claude Code）的技能没有更新，不说路径，然后按下一步处理。
4. `doctor` 失败、未安装、能力目录不匹配或运行时与 Skill 版本不一致时，读取 [environment-recovery.json](references/environment-recovery.json)，按命中的规则向同事展示一次环境恢复确认卡。不得把环境恢复确认和业务写入确认合并。
5. 环境恢复确认通过后，只执行对应安装、更新或人工授权引导；完成后重新执行 `preflight`、`doctor` 和 `capabilities`。检查通过后从原运行断点继续，不重新创建计划或重复已回读的业务写入。
6. 每次实际调用业务能力前，向用户展示一行业务状态，不展示 CLI 命令、绝对路径、凭证、版本、通道、哈希、客户值或内部对象 ID：

   ```text
   当前环境：已确认当前登录环境；本次准备处理 <capability_display_name>。
   ```

7. 业务结果中保留同一版本状态；若旧运行恢复时版本发生漂移，停止继续执行并请同事重新确认，不直接使用新规则写入业务系统。

需要产品细节时，先使用安装包内的知识索引定位主题，再向用户提供产品手册链接；索引只读，不把飞书页面内容直接当作新的执行规则。

## 准备请求

涉及准备导入数据时按需读取 [import-reminders.md](references/import-reminders.md)，识别 CompanyOwner（公司归属人）的后台账号邮箱要求。CLI 动作含 `reminders` 时先展示提醒；提醒本身不增加确认或写入步骤。

按 [runtime-contract.md](references/runtime-contract.md) 生成版本 1 请求 JSON：

- 最少包含业务目标、目标系统/对象、输入引用、源文件 SHA256、能力选项和输出目录。
- 文件任务先只读检查文件；不把客户值复制到持久运行状态。
   - 只追问会改变结果的缺失项。历史清洗优先确认真实来源列、字段类型、目标字段、处理动作、是否去重及键、重复表头和输出格式；字段创建使用 `field-types` 目录，只有已验证类型允许写入；资料任务确认每份资料的一一对应关系，并由 AI 从当前页面解析新旧入口、精确重复和必填配置。
   - 不猜测不确定值，不默认跨租户或跨对象复用；删除、覆盖和批量动作根据影响范围决定是否确认。

## 运行循环

1. 调用 `plan`，保存 `run_id` 和 `plan_sha256`。
2. 重复调用 `next`，严格按 `action_type` 处理，不跳步。
3. 每个结果写成版本 1 result JSON，再调用 `record`。证据引用使用相对标识，禁止绝对路径、凭证或客户值。
4. `ask_user`：只问当前缺失的高风险决策；取得答案后写回 `confirmed_decisions`。
5. `confirm_write`：仅在风险策略要求时向用户展示中文确认卡，包含业务目标、输入数量、实时账号/租户/对象、将执行的写入或数据规则、影响范围和输出位置。用户确认后原样回写 CLI 提供的 `confirmation_binding`。
6. `browser_action`：使用当前 Codex 浏览器适配能力执行。首次只读观察必须回写主机、账号、租户、浏览器表面和连接 ID；任何漂移都停止并重新计划，CLI 本身不控制浏览器。
7. `local_action`：对检查、差异、验证和打包使用确定性工具。客户专用映射由 AI 根据已确认规则在任务目录生成专用脚本；保留源文件，生成候选后必须用 CLI 契约验证再记录成功。
8. `blocked` 或结构化错误：先区分业务阻塞和环境阻塞。环境阻塞读取环境恢复契约并只询问一次安装、授权或降级选择；业务阻塞保留运行和证据，给出业务原因与恢复所需信息，不绕过门禁。
9. `complete` 或无剩余步骤：调用 `verify`。只有 `verified=true` 才说明本次运行步骤已经完成；外部系统操作还必须单独报告能力要求的回读或回执。资料访客侧若返回 `manual_continuation_required`，可以正常结束配置任务，但不能描述为访客下载已验证。
10. 结果已经可见后（`verify` 为 `verified=true`，或运行以 `blocked`/`failed` 结束），调用一次 `feedback prompt --run-id`。只主动问一次，不在 `ask_user`、`confirm_write` 或写入中途打断同事。没有运行编号的通用问答会话没有 `prompt` 可用，可以在结果给出后口头问一次同样的问题，同样只在同事明确同意后才提交。提示使用业务语言：

    > 这次任务结果已经出来了。是否有需要改进的地方？如果有，请回复“提交修改建议”，我会先整理成脱敏反馈，并显示真实投递状态。

11. 同事明确同意或直接说“提交修改建议”后，收集实际行为、期望行为和建议方向，按 [runtime-contract.md](references/runtime-contract.md)「反馈请求 JSON」里的字段名原样生成带 `consent=true` 的反馈 JSON（字段名写错整份会被拒收，报错不会指出是哪一项），调用 `feedback submit --run-id --request REQUEST_JSON`。按真实回执报告：`accepted_visible` 表示已在问题池可见，`accepted_pending` 表示中央已受理并等待补投，`accepted_delivery_failed` 表示中央已受理但外部投递超过 24 小时；这三种都必须附回执编号（取返回里的 `event_id`，对同事说后 8 位即可）。返回 `invalid_feedback_request` 等错误而没有回执，说明这次既没有提交、也没有保存在本机：对照示例改字段名重试一次，仍失败就如实告诉同事「没有提交成功」并附上原始报错，不得说成已提交或已保存。如果回执是 `central_receipt=false`（或 `status=client_queued`、`queued_locally=true`），只能说“已保存在本机，尚未送达，稍后自动补发”，不得说成中央已受理，也不要编造回执编号。没有运行编号时照常提交，并标记运行上下文未提供。想知道本机还有哪些反馈没送达，用只读的 `feedback list`：`central_accepted` 表示中央已受理，`in_problem_pool` 只有 `accepted_visible` 才为真；`auto_retry_exhausted` 为真说明自动补投已放弃、需要人工处理。

## 关键边界

- 每次任务只确认一次；计划、输入、环境、决策、账号、租户、对象或版本漂移后必须重新确认。
- 查询、统计、本地文件处理和低风险可回退动作不要求确认；删除、覆盖、批量改名、发布、开播、停播、权限变更等高风险动作必须绑定确认。
- 更新只在新任务开始前激活；已有旧运行不阻塞新任务。旧运行恢复时若发现版本漂移，先重新确认再继续，不静默混用规则。
- 用户说“停止”“取消”时立即调用 `cancel`，不继续后续动作，不删除已有证据。
- 用户界面使用“致趣 AI 工作台·协作版”和业务能力名称，不展示工程仓库、包名或内部对象 ID。工程版本仍单独显示，用于升级、回滚和问题定位。
- 反馈是本地优先的可选动作；同事不需要飞书 CLI、飞书登录或 GitHub 账号。反馈事件先写入本地 outbox，再由中央服务耐久受理并自动投递或补投到团队问题池；不得把本地排队描述成问题池已可见。
- 普通同事的业务结果不附加测试清理清单，只保留业务真正需要的一次确认。合成测试对象的清理只属于内部测试维护，不得转嫁为同事每次任务的额外步骤。
