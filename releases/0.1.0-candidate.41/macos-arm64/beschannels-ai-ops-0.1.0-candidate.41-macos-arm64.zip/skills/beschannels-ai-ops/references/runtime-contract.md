# 运行契约

## 命令

通过 `scripts/invoke-runtime.ps1` 调用：

```text
doctor --output json
capabilities --output json
preflight --capability lead-download|activity-meeting-create|historical-data-clean|historical-field-create|tag-operations|live-operations --output json
field-types --output json
knowledge status --output json
knowledge search --query QUERY --output json
knowledge trace --capability CAPABILITY_ID --output json
orientation status --output json
check-update --channel canary|pilot|stable --output json
plan --request REQUEST_JSON --output json
next --run-id RUN_ID --output json
record --run-id RUN_ID --result RESULT_JSON --output json
status --run-id RUN_ID --output json
verify --run-id RUN_ID --output json
cancel --run-id RUN_ID --output json
feedback prompt --run-id RUN_ID --output json
feedback submit --run-id RUN_ID --request FEEDBACK_REQUEST_JSON --output json
update --channel canary|pilot|stable --output json
sync-skills [--add-root FOLDER] --output json
rollback --output json
```

所有标准输出都是单个 JSON 对象。`ok=false` 时按 `error.code` 停止或恢复，不从错误文本猜测状态。

`doctor` 返回本次安装实际加载的 Skill、引用目录、知识索引状态和版本匹配状态。
`preflight` 只读检查运行时、Skill 和能力相关外部适配器需求，并返回 `ready`、`install_required`、`manual_action_required` 或 `degraded` 路径。它不安装软件、不修改配置，也不写入业务系统。
`check-update` 只读取并验签当前通道清单，不下载、不安装、不切换版本；返回
`up_to_date`、`update_available`、`channel_stale` 或 `check_unavailable`。
只有随后调用 `update` 并再次通过 `doctor`，才可向用户报告“已更新”。
更新不再被其他旧运行全局阻塞；旧运行继续前会检查其锁定版本。版本发生漂移时返回
`run_version_drift`，应先重新确认，不直接继续业务写入。

**技能目录**：不同 AI 助手读不同的目录（Codex 读 `~/.codex/skills`，DeepSeek Harness 读 `~/.agents/skills`，Claude Code 读 `~/.claude/skills`）。`update`、`rollback` 和 `sync-skills` 会把已验证版本的两个技能目录（`beschannels-ai-ops`、`beschannels-marketing-automation`）写进本机每一个已存在的助手目录，不碰目录里别人的技能：

- 主目录（默认 `~/.codex/skills`）必须成功，否则整个更新失败。其余目录尽力而为：写不进去的目录在结果里标 `failed` 并给出原因类型，更新本身照常完成。
- 不存在的助手目录不会被创建。显式设置了 `BESCHANNELS_AI_SKILL_ROOT` 时只写那一个目录。指向同一处的链接或联接点只写一次。
- `sync-skills --add-root FOLDER` 登记一个额外目录（记在数据目录的 `skill-roots.json`，之后每次更新都会带上它），用于技能目录不在上面三处的助手。`sync-skills` 不联网：用已安装且验过签名的版本离线补齐所有目录；找不到该版本的签名元数据时返回 `release_metadata_missing`，重新运行安装脚本即可。
- 结果里的 `skill_roots` 逐目录给出路径、角色（`primary` 或 `extra`）和状态（`synced` 或 `failed`）。
- `doctor` 同样逐目录报告 `skill_roots`，状态为 `matched`（和已装版本一致）、`stale`（版本旧）、`missing`（目录在但没有我们的技能）、`absent`（登记过但目录不在了）或 `not_installed`。只要有目录是 `stale`、`missing` 或 `absent`，`version_status` 就是 `skill_root_stale`，并附 `repair`（命令 `sync-skills`，`needs_network` 为 false）。

`field-types` 返回共享字段类型目录。`verified_creatable` 表示当前产品写入已验证；
`observed_probe_required` 表示只观察到产品界面，必须先做 schema probe；
`observed_system_managed` 表示由产品系统维护，不能由历史字段追加能力创建。
当前目录里 18 种类型是 `verified_creatable`，`AutoNumber`（页面上灰着不可选）和 `Lookup`（要指定查找对象，保存后指向没验证）是 `observed_system_managed`，`Rollup` 在产品的类型列表里不存在。`observed_probe_required` 目前没有条目，留给以后新观察到的类型。

`knowledge status` 只读取安装包内的审核索引，并区分已接入能力、手册模块和 CLI 候选数量；`knowledge search` 返回主题、状态、摘要和飞书产品手册链接。
`orientation status` 校验协作版加载的共同认知文件版本和 SHA256；`knowledge trace` 返回业务目的、飞书主题、执行契约、Eval、发布状态和反馈状态的关联。
CLI 不在每次任务中抓取或改写飞书内容，完整细节由浏览器打开 `source_url` 查看。
`verified_cli` 才表示当前版本可执行；`knowledge_only` 仅表示手册入口；`candidate_cli` 是待评审的只读优先候选，不得自动路由为可执行能力。

`feedback prompt` 在任务完成、阻塞或失败后只生成一次可选提示；`feedback submit` 要求反馈请求显式包含 `consent=true`，先把脱敏事件写入本地 `feedback/outbox/`，再提交中央接收端。只按回执显示 `accepted_visible`、`accepted_pending` 或 `accepted_delivery_failed`；回执为 `central_receipt=false`（`status=client_queued`）时只能说“已保存在本机，尚未送达，稍后自动补发”，不得说成中央已受理。没有运行编号时照常提交并将运行上下文标记为未提供。`feedback list` 只读列出本机事件（事件编号后 8 位、时间、状态、`central_accepted`（中央是否已受理）、`in_problem_pool`（是否已进问题池，只有 `accepted_visible` 为真）、`has_local_receipt`、有无问题池链接、`auto_retry_exhausted`、不可识别文件数），不输出反馈正文；`feedback sync [--budget-seconds 30]` 手动补投本机排队事件，`plan` 与 `doctor` 开始时也会以 3 秒总预算尽力补投一次。总预算由所有排队事件共享：剩余预算不足 0.5 秒即停止，预算用完就把剩余事件留在本机下次再投；自动补投对 `attempts` 已到 10 的事件跳过（手动 `feedback sync` 仍会发）。补投只是尽力而为，不保证在预算内送达。

**反馈请求 JSON**（`feedback submit --request` 读的文件，字段名必须原样；只有 `schema_version` 和 `consent` 必填，其余按同事的话都填上，缺了会被填成“[未提供…]”占位）：

```json
{
  "schema_version": 1,
  "consent": true,
  "title": "一句话标题，不超过 200 字",
  "observed_behavior": "实际发生了什么，不超过 2000 字",
  "expected_behavior": "同事期望怎样，不超过 2000 字",
  "recommendation": "建议怎么改，不超过 2000 字",
  "category": "workflow",
  "severity": "low"
}
```

`category` 可选 `bug`、`workflow`、`copy`、`capability`、`other`；`severity` 可选 `info`、`low`、`medium`、`high`、`critical`；同事没明确说到的就不写：`severity` 不要替同事估，分诊时由我们定；`category` 按同事的话选最接近的（功能坏了或结果不对写 `bug`，步骤不顺或容易点错写 `workflow`，说明书或文案不清写 `copy`，想要新能力写 `capability`），拿不准就不写。**不得多写任何字段，也不要换成近义词**（如 `actual_behavior`、`suggestion`、`run_id`）：出现没定义的字段，整份请求会被拒收，返回 `invalid_feedback_request`（新版报错会列出 `Unexpected fields` 和 `Allowed fields`；旧版只写 `contract failed at $.`，不指出是哪一项）。运行编号用 `--run-id` 参数传，不写进 JSON。不要写账号、邮箱、令牌、客户名。对同事只报回执编号后 8 位，不要转发问题池链接。请求被拒收时没有回执，这次既没有提交也没有保存在本机。

能力目录是同事可用的参考路径，不是白名单。合法但未登记的能力 ID 进入通用探索计划，至少经过环境观察、请求分析、风险判断、执行和结果回读；账号未登录、租户不明确、权限不足或适配器缺失作为环境问题返回。

查询、统计、读取、分析和本地 CSV/PDF 处理直接执行；删除、覆盖、批量改名、批量处理、发布、开播、停播和权限变更展示影响范围并取得确认。外部写入必须保留查重、幂等、独立回读和失败恢复记录。

表单、资料和活动创建在确认前增加只读解析步骤。浏览器适配器用 `resolved_decisions` 回写实际入口代际、精确查重结果、页面最终分类、必填项和直播是否请求；运行时只保存其哈希并把它绑定到确认。缺少这些解析结果时不得进入第一笔系统写入。

## 请求

请求使用 `schema_version=1`，包含 `request_id`、`capability_id`、`business_goal`、`target_system`、`target_object`、`inputs`、`options` 和 `output_dir`。**这九项都必填，不许多写别的顶层键**，多写一个整份请求就被拒收，返回 `invalid_request`。`target_system`、`target_object` 是字符串；`inputs` 可以是空数组；`options` 是对象，没有选项时写 `{}`。每个输入**只许三个键**：稳定 `input_id`、本地 `path` 和 64 位 SHA256；多写任何键（如 `name`、`note`、`type`）同样整份被拒收。新版报错会写出多出的键和允许的键（`Unexpected fields: …`、`Allowed fields: …`、`Missing fields: …`），旧版只写 `request contract failed at inputs.0.`，不指出是哪一项。

完整示例（已用真实命令验证 `plan` 通过）：

```json
{
  "schema_version": 1,
  "request_id": "REQ-20261124-001",
  "capability_id": "activity-meeting-create",
  "business_goal": "照确认卡新建一场测试会议并读回",
  "target_system": "BesChannels",
  "target_object": "测试会议",
  "inputs": [
    {"input_id": "SPEC_A", "path": "D:/work/task-01/spec.csv", "sha256": "<64 位十六进制，大小写都行>"}
  ],
  "options": {},
  "output_dir": "D:/work/task-01/outputs"
}
```

**请求文件的位置有约束：`output_dir` 必须就是请求文件所在目录，或在它下面**，也就是 request.json 要放在 `output_dir` 的上层或同一目录；否则 `plan` 返回 `output_path_outside_scope`（Output directory must stay within the request directory）。上面的示例里 request.json 放在 `D:/work/task-01/`，输出目录在它下面。CLI 持久状态只保存代号、大小、哈希和绑定，不保存客户值。

**受限环境（沙箱、只读 HOME）里换位置。** 运行时默认把安装目录和运行数据放在用户目录下：Windows 是 `%LOCALAPPDATA%\Programs\BesChannelsAIOps` 和 `%LOCALAPPDATA%\BesChannelsAIOps`，macOS 是 `~/Library/Application Support/BesChannelsAIOps` 下的 `runtime` 和 `data`，Linux 是 `~/.local/share/BesChannelsAIOps` 下的 `runtime` 和 `data`；Skill 根目录默认 `~/.codex/skills`。这些位置写不进去时，用三个环境变量改到可写的目录：`BESCHANNELS_AI_HOME`（安装目录）、`BESCHANNELS_AI_DATA_HOME`（运行数据）、`BESCHANNELS_AI_SKILL_ROOT`（Skill 根目录）。新版在这种情况下报 `runtime_io_error`，写出出错的路径和这三个变量名；旧版会误报成 `invalid_input`「A referenced JSON file could not be read」，或直接抛出 Python 异常。遇到这句话先查这几个目录能不能写，不要只盯着请求 JSON。

## 动作与结果

- `ask_user`：回写 `confirmed_decisions`。
- `confirm_write`：回写 `confirmed=true`、实时 `environment` 和 CLI 原样给出的 `confirmation_binding`，状态为 `confirmed`。
- `browser_action`：由 Codex 浏览器适配器执行，回写脱敏观察和相对证据引用。
- `local_action`：用确定性工具或任务专用脚本执行，记录输入输出哈希与验证结论。
- `blocked`：记录阻塞原因后停止。
- `complete`：调用 `verify` 结束。

资料访客侧结果另行记录为 `verified`、`manual_continuation_required` 或 `blocked`。`manual_continuation_required` 表示后台配置任务可以正常结束，但访客本人仍需注册、短信验证码或同意法律条款；结果不能写成“访客下载已验证”。这一限制仅适用于访客侧；后台配置页的必填勾选与隐私条款选择属于正常写入，按确认卡执行并回读，不影响 `lead-download` 的配置结果。

资料页里的某一项如果这次没有复现成功（控件定位不到、动作做完但回读不一致、平台没有对应入口），**不得把该步报成 `completed`**，也不得用别的项的通过掩盖它。结果卡必须分开写三件事：这一步没有自动完成；原因按证据归为「平台限制（附页面证据）」「我们尚未支持」「原因未知」之一；同事需要手动做什么。整单可以用 `partial` 结束，但必须列出未完成的那一项。


result 必含 `schema_version`、`run_id`、`step_id`、`plan_sha256`、`status`、`observations`、`evidence_refs`。同一步重复提交相同结果是幂等；不同结果会返回冲突。

## 环境观察

系统动作前的环境对象固定包含 `host`、`account`、`tenant`、`browser_surface`、`connection_id`。不要把登录凭证、Cookie、验证码或完整页面内容写入结果。

## 浏览器导航

- 浏览器适配层默认使用稳定的 `host + path` 直达；只有记录在 `navigation-routes.json` 的租户兼容路径优先点击左侧菜单。
- 直达失败时可以回退到菜单点击，但必须回读最终 path、host 和页面标题/稳定正文；`direct_verified` 与 `click_verified` 分开记录。
- 登录页、错误页、租户不匹配、账号路由重定向和控制通道超时分别记录，不把控制通道超时写成网页失败。
- 长期保存的链接必须去除 query、fragment 和动态认证参数；跨租户或跨域链接不进入稳定路径库。
