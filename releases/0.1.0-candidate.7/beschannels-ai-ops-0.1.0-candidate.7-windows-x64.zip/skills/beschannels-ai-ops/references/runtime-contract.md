# 运行契约

## 命令

通过 `scripts/invoke-runtime.ps1` 调用：

```text
doctor --output json
capabilities --output json
field-types --output json
knowledge status --output json
knowledge search --query QUERY --output json
check-update --channel canary|pilot|stable --output json
plan --request REQUEST_JSON --output json
next --run-id RUN_ID --output json
record --run-id RUN_ID --result RESULT_JSON --output json
status --run-id RUN_ID --output json
verify --run-id RUN_ID --output json
cancel --run-id RUN_ID --output json
feedback prompt --run-id RUN_ID --output json
feedback submit --run-id RUN_ID --request FEEDBACK_REQUEST_JSON --output json
update --channel canary|pilot|stable --output json
rollback --output json
```

所有标准输出都是单个 JSON 对象。`ok=false` 时按 `error.code` 停止或恢复，不从错误文本猜测状态。

`doctor` 返回本次安装实际加载的 Skill、引用目录、知识索引状态和版本匹配状态。
`check-update` 只读取并验签当前通道清单，不下载、不安装、不切换版本；返回
`up_to_date`、`update_available`、`channel_stale` 或 `check_unavailable`。
只有随后调用 `update` 并再次通过 `doctor`，才可向用户报告“已更新”。

`field-types` 返回共享字段类型目录。`verified_creatable` 表示当前产品写入已验证；
`observed_probe_required` 表示只观察到产品界面，必须先做 schema probe；
`observed_system_managed` 表示由产品系统维护，不能由历史字段追加能力创建。

`knowledge status` 只读取安装包内的审核索引，并区分已接入能力、手册模块和 CLI 候选数量；`knowledge search` 返回主题、状态、摘要和飞书产品手册链接。
CLI 不在每次任务中抓取或改写飞书内容，完整细节由浏览器打开 `source_url` 查看。
`verified_cli` 才表示当前版本可执行；`knowledge_only` 仅表示手册入口；`candidate_cli` 是待评审的只读优先候选，不得自动路由为可执行能力。

`feedback prompt` 在任务完成、阻塞或失败后只生成一次可选提示；`feedback submit` 要求反馈请求显式包含 `consent=true`，只把脱敏事件写入本地 `feedback/outbox/`，不访问飞书或 GitHub。

## 接口感知训练

对于预计重复、批量或需要跨设备交接的浏览器流程，训练结果同时保留业务动作、UI 轨迹、脱敏接口候选、回读规则和输入哈希。接口观察只代表 `interface_candidate`，不能因为返回成功就变成正式 API。

- `ui_only`：只走页面操作；
- `hybrid_guarded`：页面核验和精确查重后，候选请求最多单次提交，超时先独立回读，失败回退页面并人工接管；
- `direct_api`：只有接口契约、权限、重复保护、错误分支、回读、回滚和发布门禁全部通过后才允许。

非幂等写入、跨租户、删除、覆盖、发布和状态不明的请求不得自动重放。协作版当前只记录候选，不把候选自动加入可执行能力目录。

## 请求

请求使用 `schema_version=1`，包含 `request_id`、`capability_id`、`business_goal`、`target_system`、`target_object`、`inputs`、`options` 和 `output_dir`。每个输入包含稳定 `input_id`、本地 `path` 和 64 位 SHA256。

请求文件可留在当前任务目录；CLI 持久状态只保存代号、大小、哈希和绑定，不保存客户值。

## 动作与结果

- `ask_user`：回写 `confirmed_decisions`。
- `confirm_write`：回写 `confirmed=true`、实时 `environment` 和 CLI 原样给出的 `confirmation_binding`，状态为 `confirmed`。
- `browser_action`：由 Codex 浏览器适配器执行，回写脱敏观察和相对证据引用。
- `local_action`：用确定性工具或任务专用脚本执行，记录输入输出哈希与验证结论。
- `blocked`：记录阻塞原因后停止。
- `complete`：调用 `verify` 结束。

result 必含 `schema_version`、`run_id`、`step_id`、`plan_sha256`、`status`、`observations`、`evidence_refs`。同一步重复提交相同结果是幂等；不同结果会返回冲突。

## 环境观察

系统动作前的环境对象固定包含 `host`、`account`、`tenant`、`browser_surface`、`connection_id`。不要把登录凭证、Cookie、验证码或完整页面内容写入结果。
