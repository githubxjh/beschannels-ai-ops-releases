#!/bin/sh
set -eu

install_root="${BESCHANNELS_AI_HOME:-$HOME/Library/Application Support/BesChannelsAIOps/runtime}"
current_file="$install_root/current.json"
if [ ! -f "$current_file" ]; then
  printf '%s\n' '{"ok":false,"error":{"code":"not_installed","message":"致趣 AI 工作台尚未安装。"}}'
  exit 2
fi

version_root=$(python3 - "$current_file" <<'PY'
import json, pathlib, sys
current = json.loads(pathlib.Path(sys.argv[1]).read_text(encoding="utf-8"))
root = pathlib.Path(sys.argv[1]).parent.resolve()
target = (root / current["relative_path"]).resolve()
if root != target and root not in target.parents:
    raise SystemExit("unsafe runtime path")
print(target)
PY
)
executable="$version_root/bin/beschannels-ai"
if [ ! -x "$executable" ]; then
  printf '%s\n' '{"ok":false,"error":{"code":"runtime_missing","message":"致趣 AI 工作台运行文件缺失。"}}'
  exit 2
fi
exec "$executable" "$@"
