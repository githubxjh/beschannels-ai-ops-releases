---
name: beschannels-ai-ops
description: 统一调用致趣 AI 工作台处理 BesChannels 运营与实施任务。Use when a colleague naturally asks to 创建或核验老/新留资表单、上传或复用下载资料、生成并映射二维码、按已确认规格追加历史字段，或检查和清洗历史 Excel/CSV、修复导入失败、分批与验证数据；也用于可选地创建单个活动/会议、同事说“提交修改建议”或反馈任务体验。也用于识别并停止直播、标签恢复、删除或覆盖已有字段等 V1 未支持的近邻请求；同事不需要知道 Skill 名、CLI、路径或内部对象 ID。
metadata:
  version: "0.1.0-candidate.7"
  white_box_protocol: "v1"
---

# 致趣 AI 工作台

把用户的业务描述路由为受控运行。对用户只显示中文产品名、业务范围、必要问题、一次确认卡和结果；CLI 名、内部路径、哈希与对象 ID 仅用于内部执行和诊断。

## 路由

先读 [capability-routing.md](references/capability-routing.md)；表单任务同时读取 [form-taxonomy.md](references/form-taxonomy.md)。只选择一个能力：

- `lead-download`：留资表单、下载资料、二维码及端到端验收。
- `form-create`：按老/新表单分类、投放形态、目标对象和首要身份字段创建表单并回读。
- `activity-meeting-create`：可选的单个活动/会议创建候选；只允许受控页面执行。
- `historical-field-create`：按确认规格追加历史字段并回读完整 schema 差异。
- `legacy-data-clean`：检查和清洗历史数据 Excel/CSV、修复导入失败、分批和验证。

直播、标签恢复、直接 API、删除或覆盖已有字段、普通统计分析不进入近邻能力。活动/会议创建仅按单对象、精确查重、一次确认和独立回读执行；缺少模块决定或回读方式时停止。

## 启动

1. Windows 使用 `scripts/invoke-runtime.ps1`，macOS/Linux 使用 `scripts/invoke-runtime.sh`，执行 `doctor --output json`、`check-update --channel <current-channel> --output json` 和 `capabilities --output json`。
2. 在没有活动运行时，按当前安装通道检查更新；`update_available` 时激活签名版本，然后重新执行 `doctor` 和 `check-update`。网络不可用时继续使用已安装版本，并把版本状态标为“通道检查暂不可用”。
3. `doctor` 失败、未安装、能力目录不匹配或运行时与 Skill 版本不一致时，停止业务写入并报告“致趣 AI 工作台需要修复安装”。
4. 每次实际调用业务能力前，向用户展示一行白盒状态，使用中文产品语言，不展示 CLI 命令、绝对路径、凭证、客户值或内部对象 ID：

   ```text
   白盒状态：已加载致趣 AI 工作台 Skill <skill_version>；当前版本 <current_version>；<channel> 通道最新 <latest_version>；版本状态 <up_to_date|update_available|check_unavailable|mismatch>；本次能力 <capability_display_name>。
   ```

5. 业务结果中保留同一版本状态；若运行中版本发生漂移，只报告锁定版本和漂移状态，不切换活动运行。

需要产品细节时，先使用安装包内的知识索引定位主题，再向用户提供产品手册链接；索引只读，不把飞书页面内容直接当作新的执行规则。

## 准备请求

按 [runtime-contract.md](references/runtime-contract.md) 生成版本 1 请求 JSON：

- 最少包含业务目标、目标系统/对象、输入引用、源文件 SHA256、能力选项和输出目录。
- 文件任务先只读检查文件；不把客户值复制到持久运行状态。
   - 只追问会改变结果的缺失项。表单任务先确认老/新代际、投放形态、目标对象、首要身份字段和手机号是否必填，并分开记录提交人次与对象去重记录；活动任务确认名称、时间、分类和每个模块的配置/跳过决定；历史清洗优先确认真实来源列、字段类型、目标字段、处理动作、是否去重及键、重复表头和输出格式；字段创建使用 `field-types` 目录，只有已验证类型允许写入；资料任务确认每份资料的一一对应关系。
- 不猜测不确定值，不默认删除行，不默认覆盖已有字段，不默认跨租户或跨对象复用。

## 运行循环

1. 调用 `plan`，保存 `run_id` 和 `plan_sha256`。
2. 重复调用 `next`，严格按 `action_type` 处理，不跳步。
3. 每个结果写成版本 1 result JSON，再调用 `record`。证据引用使用相对标识，禁止绝对路径、凭证或客户值。
4. `ask_user`：只问当前缺失的高风险决策；取得答案后写回 `confirmed_decisions`。
5. `confirm_write`：向用户展示一次中文确认卡，包含业务目标、输入数量、实时账号/租户/对象、将执行的写入或数据规则、不会执行的删除/覆盖及输出位置。用户确认后原样回写 CLI 提供的 `confirmation_binding`。
6. `browser_action`：使用当前 Codex 浏览器适配能力执行。首次只读观察必须回写主机、账号、租户、浏览器表面和连接 ID；任何漂移都停止并重新计划，CLI 本身不控制浏览器。
7. `local_action`：对检查、差异、验证和打包使用确定性工具。客户专用映射由 AI 根据已确认规则在任务目录生成专用脚本；保留源文件，生成候选后必须用 CLI 契约验证再记录成功。
8. `blocked` 或结构化错误：保留运行和证据，给出业务原因与恢复所需信息，不绕过门禁。
9. `complete` 或无剩余步骤：调用 `verify`。只有 `verified=true` 才说明本次运行完成；外部系统操作还必须有能力要求的回读或回执。
10. 结果已经可见后（`verify` 为 `verified=true`，或运行以 `blocked`/`failed` 结束），调用一次 `feedback prompt --run-id`。只主动问一次，不在 `ask_user`、`confirm_write` 或写入中途打断同事。提示使用业务语言：

    > 这次任务结果已经出来了。是否有需要改进的地方？如果有，请回复“提交修改建议”，我会先整理成脱敏反馈；不会自动发送到飞书或 GitHub。

11. 同事明确同意或直接说“提交修改建议”后，收集实际行为、期望行为和建议方向，生成带 `consent=true` 的反馈 JSON，调用 `feedback submit --run-id --request REQUEST_JSON`。只报告“已保存本地脱敏反馈”，不要暗示已经同步到飞书或 GitHub。

## 关键边界

- 每次任务只确认一次；计划、输入、环境、决策、账号、租户、对象或版本漂移后必须重新确认。
- 只读步骤不要求确认。所有系统写入和会改变业务结果的数据规则必须绑定确认。
- 更新只在新任务开始前激活。活动运行继续使用锁定版本；不得在运行中替换 CLI、Skill 或能力。
- 用户说“停止”“取消”时立即调用 `cancel`，不继续后续动作，不删除已有证据。
- 用户界面使用“致趣 AI 工作台·协作版”和业务能力名称，不展示工程仓库、包名或内部对象 ID。工程版本仍单独显示，用于升级、回滚和问题定位。
- 反馈是本地优先的可选动作；同事不需要飞书 CLI、飞书登录或 GitHub 账号。反馈事件写入本地 outbox，后续由维护者同步到团队问题池。
