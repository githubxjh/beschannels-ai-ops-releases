[CmdletBinding()]
param(
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$CliArgs
)

$ErrorActionPreference = 'Stop'
$installRoot = if ($env:BESCHANNELS_AI_HOME) {
    [System.IO.Path]::GetFullPath($env:BESCHANNELS_AI_HOME)
} else {
    Join-Path $env:LOCALAPPDATA 'Programs\BesChannelsAIOps'
}
$currentPath = Join-Path $installRoot 'current.json'
if (-not (Test-Path -LiteralPath $currentPath -PathType Leaf)) {
    throw '致趣 AI 工作台尚未安装或 current.json 缺失。'
}
$current = Get-Content -LiteralPath $currentPath -Raw -Encoding UTF8 | ConvertFrom-Json
$versionRoot = [System.IO.Path]::GetFullPath((Join-Path $installRoot ([string]$current.relative_path)))
if (-not $versionRoot.StartsWith([System.IO.Path]::GetFullPath($installRoot), [System.StringComparison]::OrdinalIgnoreCase)) {
    throw '致趣 AI 工作台当前版本路径越界。'
}
$executable = Join-Path $versionRoot 'bin\beschannels-ai.exe'
if (-not (Test-Path -LiteralPath $executable -PathType Leaf)) {
    throw '致趣 AI 工作台当前版本缺少运行程序。'
}
& $executable @CliArgs
exit $LASTEXITCODE
